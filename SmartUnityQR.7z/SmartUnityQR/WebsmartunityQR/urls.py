from django.contrib import admin
from django.urls import include, path


urlpatterns = [
    path('', include('WebsmartunityQR.urls')),
    path('login/', include('login.urls')),
    path('admin/', admin.site.urls),
    # path('adduser/', include('adduser.urls')),
    # path('master/', include('master.urls')),
    # path('checklist/', include('checklist.urls')),
]
